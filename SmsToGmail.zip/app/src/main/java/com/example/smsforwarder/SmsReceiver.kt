package com.example.smsforwarder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log
import kotlin.concurrent.thread

class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        if (!Prefs.isEnabled(context)) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (messages.isNullOrEmpty()) return

        val filterNumber = Prefs.getFilterNumber(context).trim()
        val senderGmail = Prefs.getTargetEmail(context) // account used to send AND receive (send-to-self)
        val appPassword = Prefs.getAppPassword(context)

        if (senderGmail.isEmpty() || appPassword.isEmpty()) {
            Log.w("SmsReceiver", "Email not configured yet, skipping forward")
            return
        }

        // Group multipart SMS into one body per sender
        val bodyBuilder = StringBuilder()
        var fromAddress = ""
        for (msg in messages) {
            fromAddress = msg.originatingAddress ?: ""
            bodyBuilder.append(msg.messageBody)
        }

        // If a filter number is set, only forward messages coming from that number.
        // Empty filter = forward everything.
        val matches = filterNumber.isEmpty() || fromAddress.contains(filterNumber)
        if (!matches) return

        val body = bodyBuilder.toString()
        val subject = "SMS from $fromAddress"

        // Network calls (SMTP) must NOT run on the main thread.
        thread {
            EmailSender.send(
                fromGmail = senderGmail,
                appPassword = appPassword,
                toEmail = senderGmail,
                subject = subject,
                body = body
            )
        }
    }
}
