package com.example.smsforwarder

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.MobileAds

class MainActivity : AppCompatActivity() {

    private lateinit var editFilterNumber: EditText
    private lateinit var editTargetEmail: EditText
    private lateinit var editAppPassword: EditText
    private lateinit var checkEnabled: CheckBox

    private val requiredPermissions = arrayOf(
        Manifest.permission.RECEIVE_SMS,
        Manifest.permission.READ_SMS
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Init AdMob and load a banner ad
        MobileAds.initialize(this) {}
        val adView = findViewById<com.google.android.gms.ads.AdView>(R.id.adView)
        adView.loadAd(AdRequest.Builder().build())

        editFilterNumber = findViewById(R.id.editFilterNumber)
        editTargetEmail = findViewById(R.id.editTargetEmail)
        editAppPassword = findViewById(R.id.editAppPassword)
        checkEnabled = findViewById(R.id.checkEnabled)

        // Load saved settings
        editFilterNumber.setText(Prefs.getFilterNumber(this))
        editTargetEmail.setText(Prefs.getTargetEmail(this))
        editAppPassword.setText(Prefs.getAppPassword(this))
        checkEnabled.isChecked = Prefs.isEnabled(this)

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            saveSettings()
        }

        findViewById<Button>(R.id.btnRequestPermission).setOnClickListener {
            requestSmsPermissions()
        }

        requestSmsPermissions()
    }

    private fun saveSettings() {
        val filter = editFilterNumber.text.toString().trim()
        val email = editTargetEmail.text.toString().trim()
        val pass = editAppPassword.text.toString().trim()
        val enabled = checkEnabled.isChecked

        if (email.isEmpty() || pass.isEmpty()) {
            Toast.makeText(this, "Gmail aur App Password dono zaroori hain", Toast.LENGTH_SHORT).show()
            return
        }

        Prefs.save(this, filter, email, pass, enabled)
        Toast.makeText(this, "Settings saved. Filter: '$filter' -> $email", Toast.LENGTH_SHORT).show()
    }

    private fun requestSmsPermissions() {
        val notGranted = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (notGranted.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, notGranted.toTypedArray(), 100)
        }
    }
}
