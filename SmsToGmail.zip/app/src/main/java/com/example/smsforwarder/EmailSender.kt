package com.example.smsforwarder

import android.util.Log
import java.util.Properties
import javax.mail.Authenticator
import javax.mail.Message
import javax.mail.PasswordAuthentication
import javax.mail.Session
import javax.mail.Transport
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeMessage

/**
 * Sends an email through Gmail's SMTP server using an App Password.
 * This MUST be called from a background thread (never the main/UI thread).
 */
object EmailSender {

    private const val TAG = "EmailSender"

    fun send(fromGmail: String, appPassword: String, toEmail: String, subject: String, body: String): Boolean {
        return try {
            val props = Properties().apply {
                put("mail.smtp.auth", "true")
                put("mail.smtp.starttls.enable", "true")
                put("mail.smtp.host", "smtp.gmail.com")
                put("mail.smtp.port", "587")
            }

            val session = Session.getInstance(props, object : Authenticator() {
                override fun getPasswordAuthentication(): PasswordAuthentication {
                    return PasswordAuthentication(fromGmail, appPassword)
                }
            })

            val message = MimeMessage(session).apply {
                setFrom(InternetAddress(fromGmail))
                setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail))
                setSubject(subject)
                setText(body)
            }

            Transport.send(message)
            Log.i(TAG, "Email sent successfully to $toEmail")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send email: ${e.message}", e)
            false
        }
    }
}
