package com.example.smsforwarder

import android.content.Context

/**
 * Simple wrapper around SharedPreferences to store the user's settings:
 *  - the sender number to filter on (e.g. "8558")
 *  - the destination Gmail address
 *  - the Gmail App Password used to authenticate via SMTP
 *
 * NOTE: An "App Password" is a 16-character code Google generates for you
 * (Google Account -> Security -> 2-Step Verification -> App Passwords).
 * NEVER use your real Gmail login password here.
 */
object Prefs {
    private const val FILE = "sms_forwarder_prefs"
    private const val KEY_FILTER_NUMBER = "filter_number"
    private const val KEY_TARGET_EMAIL = "target_email"
    private const val KEY_APP_PASSWORD = "app_password"
    private const val KEY_ENABLED = "enabled"

    fun save(context: Context, filterNumber: String, targetEmail: String, appPassword: String, enabled: Boolean) {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        sp.edit()
            .putString(KEY_FILTER_NUMBER, filterNumber)
            .putString(KEY_TARGET_EMAIL, targetEmail)
            .putString(KEY_APP_PASSWORD, appPassword)
            .putBoolean(KEY_ENABLED, enabled)
            .apply()
    }

    fun getFilterNumber(context: Context): String =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_FILTER_NUMBER, "") ?: ""

    fun getTargetEmail(context: Context): String =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_TARGET_EMAIL, "") ?: ""

    fun getAppPassword(context: Context): String =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_APP_PASSWORD, "") ?: ""

    fun isEnabled(context: Context): Boolean =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false)
}
