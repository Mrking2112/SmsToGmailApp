# SMS to Gmail Forwarder

Ye app ek specific number (jaise `8558`) se aane wali SMS ko automatic aapke Gmail par forward kar deta hai. Ads (AdMob) integrated hain taake app se earning bhi ho sake.

## ⚠️ Zaroori baatein (pehle padhein)

1. **Sirf apne phone / apni marzi se app install karo.** Kisi doosre ke phone par bina uski razamandi ke ye app install karna (khaas kar OTP/banking messages churane ke liye) illegal hai aur fraud counts hota hai. Ye code sirf legitimate personal use (apne SMS apne Gmail par forward karna) ke liye hai.
2. **Play Store par publish nahi ho sakta** jab tak app "Default SMS handler" na ho — Google ki policy SMS-read permission ko restrict karti hai. Isliye ye APK sirf **direct download / GitHub Releases / sideload** ke through distribute hoga, Play Store se nahi.
3. Gmail ka **real password kabhi na dalna** — sirf "App Password" use karo (neeche steps hain).

## Step 1 — Gmail App Password banao

1. https://myaccount.google.com/security par jao
2. "2-Step Verification" ON karo (agar pehle se nahi hai)
3. Search karo "App Passwords" → naya app password generate karo (16 characters)
4. Ye password app ke andar "Gmail App Password" field mein daalna hai (real Gmail password nahi)

## Step 2 — AdMob account banao (earning ke liye)

1. https://apps.admob.com par jao aur account banao
2. Naya app add karo → Android
3. Aapko ek **App ID** milega (`ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX`) aur ek **Ad Unit ID** (`ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX`)
4. `AndroidManifest.xml` mein `com.google.android.gms.ads.APPLICATION_ID` ki value replace karo apne real App ID se
5. `activity_main.xml` mein `app:adUnitId` ki value replace karo apne real Ad Unit ID se
6. Jab tak real IDs nahi daaloge, sirf Google ke test ads dikhenge (jo abhi code mein already lagi hain) — is se koi earning nahi hoti, sirf testing ke liye hain.

**Warning:** Apne khud ke ads par khud click mat karna (invalid traffic) — AdMob account permanently ban ho sakta hai.

## Step 3 — Build karo (Android Studio)

1. Android Studio install karo: https://developer.android.com/studio
2. Is poore folder ko "Open Project" se kholo
3. Gradle sync hone do (internet chahiye hoga dependencies download karne ke liye)
4. Build → Generate Signed Bundle/APK → APK choose karo → apni keystore banao (ya existing use karo) → Release build → Finish
5. APK `app/release/app-release.apk` mein mil jayega

## Step 4 — GitHub par upload karo

```bash
git init
git add .
git commit -m "Initial commit: SMS to Gmail Forwarder"
git branch -M main
git remote add origin https://github.com/<aapka-username>/<repo-name>.git
git push -u origin main
```

APK ko GitHub "Releases" section mein upload karo (Releases → Draft a new release → APK file attach karo) taake log directly download kar sakein.

## Step 5 (Easy way) — GitHub Actions se automatic APK build

Is repo mein `.github/workflows/build.yml` already maujood hai. Isse **Android Studio ki bilkul zaroorat nahi** — GitHub khud APK bana dega.

1. Poora folder GitHub par push karo (upar wale git commands se)
2. GitHub repo page par jao → top tabs mein **"Actions"** click karo
3. "Build APK" workflow dikhega (push hote hi khud chal jayega, ya "Run workflow" button se manually bhi chala sakte ho)
4. Build complete hone ka wait karo (2-4 min, green tick ✅ aayega)
5. Us workflow run ke andar neeche **"Artifacts"** section mein `app-debug-apk` milega → click karke download karo → andar `app-debug.apk` hoga

**Note:** Ye **debug APK** banata hai (testing ke liye, bina keystore signing ke) — install ho jayega aur poori tarah kaam karega, bas Play Store par upload karne layak nahi hoga (uske liye Step 3 wala signed release APK chahiye hota).

## Kaise kaam karta hai

- `SmsReceiver.kt` — har incoming SMS ko catch karta hai
- Agar filter number (e.g. `8558`) match karta hai (ya filter khali hai), to SMS ka content background thread par Gmail SMTP se email kar diya jata hai
- `MainActivity.kt` — settings screen jahan number, Gmail, aur app password set karte hain
- `Prefs.kt` — settings ko phone par save karta hai (SharedPreferences)
- `EmailSender.kt` — JavaMail library se Gmail SMTP (smtp.gmail.com:587) use karke email bhejta hai

## Permissions ki wajah

- `RECEIVE_SMS`, `READ_SMS` — incoming SMS padhne ke liye
- `INTERNET` — email bhejne aur ads load karne ke liye
